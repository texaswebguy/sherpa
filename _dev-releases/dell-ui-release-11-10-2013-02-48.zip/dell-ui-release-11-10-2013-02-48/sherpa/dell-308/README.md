Dell 308 Theme for Bootstrap 2.3.2
======================

 Dell Sherpa v0.7 - 10/11/2013
 ---------------------

**Change Log**

- Defect 341294:Sherpa:: Alert Icons are not displaying based on the type
- Defect 342291:Sherpa :: TextBox with fixed width
- Defect 341489:Sherpa :: Wrong text-align attribute in .btn class
- Defect 349910:Sherpa :: Headline colors in modal are the wrong color

**Known issues, change log and theme documentation**

  - A comprehensive [CSS overview] is provided with many examples and ability to easily copy html.
  - You can also view the documentation in a [responsive simulator].
  - [Known issues] explain discrepancies between Dell 308 and Bootstrap.
  - You can also view and account of all ongoing changes in the [change log].


[CSS overview]: http://open.gsdprototypes.com/sherpa/
[responsive simulator]: http://open.gsdprototypes.com/sherpa/simulator.html
[Known issues]: http://open.gsdprototypes.com/sherpa/known-issues.html
[change log]: http://open.gsdprototypes.com/sherpa/change-log.html
