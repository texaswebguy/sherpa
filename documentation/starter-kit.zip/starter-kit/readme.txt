This starter kit was created on 29-10-2013 - 08:40 AM 
If you have any questions please contact Bo Lora bo_lora@dell.com 
